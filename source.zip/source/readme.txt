\source 包含以下文件夹或文件

SCCPU           实现 add/sub/and/or/slt/sltu/addu/subu/addi/ori/lw/sw/beq/j 14条指令单周期CPU 的verilog代码
SCCPU_SIMTop    仿真测试  add/sub/and/or/slt/sltu/addu/subu/addi/ori/lw/sw/beq/j 14条指令单周期CPU 的verilog代码

SCCPUJAL        实现 add/sub/and/or/slt/sltu/addu/subu/addi/ori/lw/sw/beq/j/jal 15条指令单周期CPU 的verilog代码
SCCPUJAL_SIMTop 仿真测试 add/sub/and/or/slt/sltu/addu/subu/addi/ori/lw/sw/beq/j/jal 15条指令单周期CPU 的verilog代码

SCCPU_FPGATop   单周期 CPU FPGA 工程除 CPU 部分的其他verilog代码

MCCPU           实现 add/sub/and/or/slt/sltu/addu/subu/addi/ori/lw/sw/beq/j/jal 15条指令单周期CPU 的verilog代码
MCCPU_SIMTop    仿真测试多周期 CPU 的verilog代码
MCCPU_FPGATop   多周期 CPU FPGA 工程除 CPU 部分的其他verilog代码

Testing Code    测试asm代码以及其对应的dat或coe文件

Nexys4DDR_CPU.xdc 开发板约束文件
